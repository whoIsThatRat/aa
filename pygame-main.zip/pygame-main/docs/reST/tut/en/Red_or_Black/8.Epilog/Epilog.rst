====================================
Author: Youngwook Kim (Korean)
====================================

====================================
Contact: rumia0601@gmail.com
====================================

====================================
Epilog
====================================

However, this is end of tutorial. This tutorial covers only a few of Pygame. But don’t worry. Programming is the most creative activity human can do. Immanuel Kant said “Genius is the innate mental aptitude through which nature gives the rule to art”. Programming is making a rule and give it to computer. If rule is made, computer can do anything within rule. So, number of cases incredibly increase.

What is conclusion? **Output is greater than input**. We can implement much more program within our knowledge. Or, we can learn new knowledge easily by connecting it to old knowledge. That’s trait of programming. And so is game. “Radom” is the key concept for every game. (including simple game made on this tutorial!) number of cases is much greater when random variable is concerned. If random variable starts to affect another random variable and so on, output will be greater like Avalanche. That’s why game is interesting. Concept of “Random” is the only unique characteristic for game in comparison to novel, music or movie. Think about Tetris. How much effort Alexey Leonidovich Pajitnov spent? Do you think it is greater than sum of Tetris player’s playing time above the world, along 35 years? That’s ultimate example of both power of programming and game.

So, game makers are Avalanche makers. Now it’s time to create any game! Learn! Utilize! Go through trial and errors!

